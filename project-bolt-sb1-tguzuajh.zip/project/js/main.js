// Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
  // Mobile menu toggle
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  const navList = document.querySelector('.nav-list');
  
  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener('click', function() {
      mobileMenuToggle.classList.toggle('active');
      navList.classList.toggle('active');
    });
  }
  
  // Handle page transitions on navigation
  const navLinks = document.querySelectorAll('.nav-link');
  const pageTransition = document.querySelector('.page-transition');
  
  navLinks.forEach(link => {
    if (!link.classList.contains('active')) {
      link.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href.charAt(0) !== '#') {
          e.preventDefault();
          pageTransition.classList.add('active');
          
          setTimeout(() => {
            window.location.href = href;
          }, 500);
        }
      });
    }
  });
  
  // Handle animations for elements when they come into view
  const animateOnScroll = function() {
    const elements = document.querySelectorAll('.fade-in, .section-title, .timeline-item, .stat-number');
    
    elements.forEach(element => {
      const elementTop = element.getBoundingClientRect().top;
      const elementVisible = 150;
      
      if (elementTop < window.innerHeight - elementVisible) {
        element.classList.add('visible');
      }
    });
  };
  
  // Run once on initial load
  animateOnScroll();
  
  // Add event listener for scroll
  window.addEventListener('scroll', animateOnScroll);
  
  // Add fade-in classes to elements
  const addFadeInClasses = function() {
    const sections = document.querySelectorAll('section');
    
    sections.forEach(section => {
      const elements = section.querySelectorAll('h2, h3, p, .btn, .feature-card, .team-member, .stat-card');
      
      elements.forEach((element, index) => {
        if (!element.classList.contains('fade-in')) {
          element.classList.add('fade-in', `fade-in-${(index % 5) + 1}`);
        }
      });
    });
  };
  
  addFadeInClasses();
});