// Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
  // Sidebar navigation
  const sidebarLinks = document.querySelectorAll('.sidebar-link');
  const dashboardSections = document.querySelectorAll('.dashboard-section');
  
  sidebarLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href').substring(1);
      
      // Update active link
      sidebarLinks.forEach(l => {
        l.parentElement.classList.remove('active');
      });
      this.parentElement.classList.add('active');
      
      // Show target section
      dashboardSections.forEach(section => {
        section.classList.remove('active');
        
        if (section.id === targetId) {
          section.classList.add('active');
        }
      });
    });
  });
  
  // Upload functionality
  const uploadArea = document.getElementById('uploadArea');
  const uploadProgress = document.getElementById('uploadProgress');
  const progressFill = document.getElementById('progressFill');
  const progressPercent = document.getElementById('progressPercent');
  const browseBtn = document.getElementById('browseBtn');
  const fileInput = document.getElementById('fileInput');
  
  if (uploadArea && fileInput) {
    // Handle drag events
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      uploadArea.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
      uploadArea.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
      uploadArea.addEventListener(eventName, unhighlight, false);
    });
    
    function highlight() {
      uploadArea.classList.add('dragover');
    }
    
    function unhighlight() {
      uploadArea.classList.remove('dragover');
    }
    
    // Handle file drop
    uploadArea.addEventListener('drop', handleDrop, false);
    
    function handleDrop(e) {
      const dt = e.dataTransfer;
      const files = dt.files;
      
      if (files.length > 0) {
        handleFiles(files);
      }
    }
    
    // Handle file input change
    fileInput.addEventListener('change', function() {
      if (this.files.length > 0) {
        handleFiles(this.files);
      }
    });
    
    // Handle browse button click
    if (browseBtn) {
      browseBtn.addEventListener('click', function() {
        fileInput.click();
      });
    }
    
    // Handle uploads
    function handleFiles(files) {
      uploadArea.classList.add('hidden');
      uploadProgress.classList.remove('hidden');
      
      // Simulate upload progress
      window.simulateUploadProgress(progressFill, progressPercent, function() {
        // Show success message
        uploadProgress.innerHTML = `
          <div class="upload-success">
            <div class="success-icon">✓</div>
            <p>Upload complete!</p>
            <button class="btn btn-primary btn-sm mt-2" id="uploadMoreBtn">Upload More</button>
          </div>
        `;
        
        // Add event listener to upload more button
        document.getElementById('uploadMoreBtn').addEventListener('click', function() {
          uploadProgress.innerHTML = `
            <div class="progress-bar">
              <div class="progress-fill" id="progressFill"></div>
            </div>
            <div class="progress-text">Uploading... <span id="progressPercent">0</span>%</div>
          `;
          uploadProgress.classList.add('hidden');
          uploadArea.classList.remove('hidden');
          
          // Reset progress elements
          progressFill = document.getElementById('progressFill');
          progressPercent = document.getElementById('progressPercent');
        });
      });
    }
  }
  
  // Update donut chart on browser resize
  function updateDonutChart() {
    const donutSegments = document.querySelectorAll('.donut-segment');
    
    donutSegments.forEach(segment => {
      const percentage = segment.style.getPropertyValue('--percentage') || 
                        segment.getAttribute('data-percentage') || 0;
      
      if (window.innerWidth < 768) {
        // For mobile sizes, adjust clip path
        segment.style.clipPath = `polygon(50% 50%, 50% 0, 100% 0, 100% 100%, 0 100%, 0 0, 50% 0)`;
      } else {
        segment.style.clipPath = `polygon(50% 50%, 50% 0, 100% 0, 100% 100%, 0 100%, 0 0, 50% 0)`;
      }
      
      segment.style.transform = `rotate(${percentage * 3.6}deg)`;
    });
  }
  
  // Run once on load
  updateDonutChart();
  
  // And on window resize
  window.addEventListener('resize', updateDonutChart);
});