// Explorer JavaScript
document.addEventListener('DOMContentLoaded', function() {
  // View toggle functionality
  const viewBtns = document.querySelectorAll('.view-btn');
  const filesGrid = document.getElementById('filesGrid');
  const filesList = document.getElementById('filesList');
  
  viewBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      // Update active button
      viewBtns.forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      
      // Show corresponding view
      const viewType = this.getAttribute('data-view');
      
      if (viewType === 'grid') {
        filesGrid.classList.add('active');
        filesList.classList.remove('active');
      } else if (viewType === 'list') {
        filesGrid.classList.remove('active');
        filesList.classList.add('active');
      }
    });
  });
  
  // Location and bucket navigation
  const locationLinks = document.querySelectorAll('.location-link');
  const bucketLinks = document.querySelectorAll('.bucket-link');
  
  locationLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Update active link
      locationLinks.forEach(l => {
        l.parentElement.classList.remove('active');
      });
      this.parentElement.classList.add('active');
      
      // Update breadcrumb
      updateBreadcrumb(this.textContent);
    });
  });
  
  bucketLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Update active link
      bucketLinks.forEach(l => {
        l.parentElement.classList.remove('active');
      });
      this.parentElement.classList.add('active');
      
      // Update breadcrumb
      updateBreadcrumb(this.textContent);
    });
  });
  
  function updateBreadcrumb(locationName) {
    const breadcrumbList = document.querySelector('.breadcrumb-list');
    if (breadcrumbList) {
      breadcrumbList.innerHTML = `
        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Home</a></li>
        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">${locationName}</a></li>
      `;
    }
  }
  
  // File grid navigation
  const fileCards = document.querySelectorAll('.file-card');
  
  fileCards.forEach(card => {
    card.addEventListener('click', function() {
      const fileName = this.querySelector('.file-name').textContent;
      const isFolder = this.classList.contains('folder');
      
      if (isFolder) {
        // For folders, navigate into the folder
        const breadcrumbList = document.querySelector('.breadcrumb-list');
        const currentPath = Array.from(breadcrumbList.querySelectorAll('.breadcrumb-link'))
          .map(link => link.textContent)
          .filter(text => text !== 'Home')
          .join('/');
        
        const newPath = currentPath ? `${currentPath}/${fileName}` : fileName;
        
        breadcrumbList.innerHTML += `
          <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">${fileName}</a></li>
        `;
        
        // Simulate loading new content
        simulateLoading();
      } else {
        // For files, show file preview
        showFilePreview(fileName);
      }
    });
  });
  
  function simulateLoading() {
    const explorerContent = document.querySelector('.explorer-content');
    
    // Add loading state
    explorerContent.classList.add('loading');
    explorerContent.innerHTML = `
      <div class="loading-indicator">
        <div class="spinner"></div>
        <p>Loading folder contents...</p>
      </div>
    `;
    
    // Simulate delay and then restore content
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  }
  
  function showFilePreview(fileName) {
    // Create modal for file preview
    const modal = document.createElement('div');
    modal.className = 'file-preview-modal';
    
    const fileType = determineFileType(fileName);
    let previewContent = '';
    
    switch (fileType) {
      case 'image':
        previewContent = `
          <div class="preview-image">
            <div class="image-placeholder">
              <span class="file-icon">🖼️</span>
              <p>${fileName}</p>
            </div>
          </div>
        `;
        break;
      case 'document':
        previewContent = `
          <div class="preview-document">
            <div class="document-placeholder">
              <span class="file-icon">📄</span>
              <p>${fileName}</p>
              <p class="text-muted">Document preview not available</p>
            </div>
          </div>
        `;
        break;
      default:
        previewContent = `
          <div class="preview-generic">
            <div class="generic-placeholder">
              <span class="file-icon">📁</span>
              <p>${fileName}</p>
              <p class="text-muted">Preview not available</p>
            </div>
          </div>
        `;
    }
    
    modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h3>File Preview</h3>
          <button class="close-btn">&times;</button>
        </div>
        <div class="modal-body">
          ${previewContent}
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary">Download</button>
          <button class="btn btn-primary">Share</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add classes to animate modal in
    setTimeout(() => {
      modal.classList.add('active');
    }, 10);
    
    // Close button functionality
    modal.querySelector('.close-btn').addEventListener('click', () => {
      modal.classList.remove('active');
      
      // Remove modal after animation completes
      setTimeout(() => {
        document.body.removeChild(modal);
      }, 300);
    });
  }
  
  function determineFileType(fileName) {
    const extension = fileName.split('.').pop().toLowerCase();
    
    if (['jpg', 'jpeg', 'png', 'gif', 'svg'].includes(extension)) {
      return 'image';
    } else if (['doc', 'docx', 'pdf', 'txt'].includes(extension)) {
      return 'document';
    } else if (['xls', 'xlsx', 'csv'].includes(extension)) {
      return 'spreadsheet';
    } else if (['ppt', 'pptx'].includes(extension)) {
      return 'presentation';
    } else {
      return 'other';
    }
  }
  
  // Upload functionality
  const uploadBtn = document.getElementById('uploadBtn');
  const explorerFileInput = document.getElementById('explorerFileInput');
  
  if (uploadBtn && explorerFileInput) {
    uploadBtn.addEventListener('click', function() {
      explorerFileInput.click();
    });
    
    explorerFileInput.addEventListener('change', function() {
      if (this.files.length > 0) {
        simulateFileUpload(this.files);
      }
    });
  }
  
  function simulateFileUpload(files) {
    // Create upload progress modal
    const modal = document.createElement('div');
    modal.className = 'upload-progress-modal';
    
    let fileItems = '';
    for (let i = 0; i < files.length; i++) {
      fileItems += `
        <div class="file-item">
          <div class="file-info">
            <span class="file-icon">📄</span>
            <span class="file-name">${files[i].name}</span>
          </div>
          <div class="file-progress">
            <div class="progress-bar">
              <div class="progress-fill" id="progress-${i}" style="width: 0%"></div>
            </div>
            <span class="progress-text" id="progress-text-${i}">0%</span>
          </div>
        </div>
      `;
    }
    
    modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h3>Uploading Files</h3>
          <button class="close-btn">&times;</button>
        </div>
        <div class="modal-body">
          <div class="file-list">
            ${fileItems}
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Animate modal in
    setTimeout(() => {
      modal.classList.add('active');
      
      // Simulate progress for each file
      for (let i = 0; i < files.length; i++) {
        const progressFill = document.getElementById(`progress-${i}`);
        const progressText = document.getElementById(`progress-text-${i}`);
        
        // Delay start slightly for each file
        setTimeout(() => {
          simulateFileProgress(progressFill, progressText, i === files.length - 1 ? completeUpload : null);
        }, i * 500);
      }
    }, 10);
    
    // Close button functionality
    modal.querySelector('.close-btn').addEventListener('click', () => {
      modal.classList.remove('active');
      
      setTimeout(() => {
        document.body.removeChild(modal);
      }, 300);
    });
    
    function completeUpload() {
      // Add complete button to modal
      const modalFooter = document.createElement('div');
      modalFooter.className = 'modal-footer';
      modalFooter.innerHTML = `
        <button class="btn btn-primary" id="completeBtn">Complete</button>
      `;
      
      modal.querySelector('.modal-content').appendChild(modalFooter);
      
      // Add event listener to complete button
      document.getElementById('completeBtn').addEventListener('click', () => {
        modal.classList.remove('active');
        
        setTimeout(() => {
          document.body.removeChild(modal);
          location.reload(); // Refresh to show new files
        }, 300);
      });
    }
  }
  
  function simulateFileProgress(progressFill, progressText, callback) {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 10;
      if (progress > 100) progress = 100;
      
      progressFill.style.width = `${progress}%`;
      progressText.textContent = `${Math.round(progress)}%`;
      
      if (progress >= 100) {
        clearInterval(interval);
        
        // Mark as complete
        progressFill.style.backgroundColor = 'var(--success-color)';
        progressText.textContent = 'Complete';
        
        if (typeof callback === 'function') {
          setTimeout(callback, 500);
        }
      }
    }, 200);
  }
  
  // Search functionality
  const searchInput = document.querySelector('.search-input');
  const searchBtn = document.querySelector('.search-btn');
  
  if (searchInput && searchBtn) {
    searchBtn.addEventListener('click', () => performSearch());
    
    searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        performSearch();
      }
    });
  }
  
  function performSearch() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    
    if (searchTerm.length > 0) {
      // Filter file cards in grid view
      const fileCards = document.querySelectorAll('.file-card');
      let foundCount = 0;
      
      fileCards.forEach(card => {
        const fileName = card.querySelector('.file-name').textContent.toLowerCase();
        
        if (fileName.includes(searchTerm)) {
          card.style.display = '';
          card.classList.add('search-highlight');
          setTimeout(() => {
            card.classList.remove('search-highlight');
          }, 2000);
          foundCount++;
        } else {
          card.style.display = 'none';
        }
      });
      
      // Filter file rows in list view
      const fileRows = document.querySelectorAll('.file-row');
      
      fileRows.forEach(row => {
        const fileName = row.querySelector('.file-name-cell').textContent.toLowerCase();
        
        if (fileName.includes(searchTerm)) {
          row.style.display = '';
          row.classList.add('search-highlight');
          setTimeout(() => {
            row.classList.remove('search-highlight');
          }, 2000);
        } else {
          row.style.display = 'none';
        }
      });
      
      // Show search results message
      showMessage(`Found ${foundCount} matching files for "${searchTerm}"`);
    }
  }
  
  function showMessage(message) {
    // Create message element
    const messageEl = document.createElement('div');
    messageEl.className = 'message-toast';
    messageEl.textContent = message;
    
    document.body.appendChild(messageEl);
    
    // Animate in
    setTimeout(() => {
      messageEl.classList.add('active');
      
      // Automatically remove after delay
      setTimeout(() => {
        messageEl.classList.remove('active');
        
        setTimeout(() => {
          document.body.removeChild(messageEl);
        }, 300);
      }, 3000);
    }, 10);
  }
  
  // Sorting functionality
  const sortSelect = document.getElementById('sortBy');
  
  if (sortSelect) {
    sortSelect.addEventListener('change', () => {
      const sortBy = sortSelect.value;
      sortFiles(sortBy);
    });
  }
  
  function sortFiles(sortBy) {
    // Sort grid view
    const fileGrid = document.getElementById('filesGrid');
    const fileCards = Array.from(fileGrid.querySelectorAll('.file-card'));
    
    fileCards.sort((a, b) => {
      const aName = a.querySelector('.file-name').textContent;
      const bName = b.querySelector('.file-name').textContent;
      
      // Sort folders first
      const aIsFolder = a.classList.contains('folder');
      const bIsFolder = b.classList.contains('folder');
      
      if (aIsFolder && !bIsFolder) return -1;
      if (!aIsFolder && bIsFolder) return 1;
      
      // Then sort by the selected criteria
      switch (sortBy) {
        case 'name':
          return aName.localeCompare(bName);
        case 'type':
          const aExt = aName.split('.').pop() || '';
          const bExt = bName.split('.').pop() || '';
          return aExt.localeCompare(bExt) || aName.localeCompare(bName);
        case 'date':
        case 'size':
          // For demo, we'll just use name as fallback
          return aName.localeCompare(bName);
        default:
          return 0;
      }
    });
    
    // Reappend sorted elements
    fileCards.forEach(card => {
      fileGrid.appendChild(card);
    });
    
    // Sort list view
    const fileTable = document.querySelector('.files-table tbody');
    const fileRows = Array.from(fileTable.querySelectorAll('tr'));
    
    fileRows.sort((a, b) => {
      const aName = a.querySelector('.file-name-cell').textContent;
      const bName = b.querySelector('.file-name-cell').textContent;
      
      // Sort folders first
      const aIsFolder = a.classList.contains('folder');
      const bIsFolder = b.classList.contains('folder');
      
      if (aIsFolder && !bIsFolder) return -1;
      if (!aIsFolder && bIsFolder) return 1;
      
      // Then sort by the selected criteria
      switch (sortBy) {
        case 'name':
          return aName.localeCompare(bName);
        case 'type':
          const aType = a.querySelector('td:nth-child(2)').textContent;
          const bType = b.querySelector('td:nth-child(2)').textContent;
          return aType.localeCompare(bType) || aName.localeCompare(bName);
        case 'size':
          const aSize = a.querySelector('td:nth-child(3)').textContent;
          const bSize = b.querySelector('td:nth-child(3)').textContent;
          return aSize.localeCompare(bSize) || aName.localeCompare(bName);
        case 'date':
          const aDate = a.querySelector('td:nth-child(4)').textContent;
          const bDate = b.querySelector('td:nth-child(4)').textContent;
          return aDate.localeCompare(bDate) || aName.localeCompare(bName);
        default:
          return 0;
      }
    });
    
    // Reappend sorted elements
    fileRows.forEach(row => {
      fileTable.appendChild(row);
    });
    
    showMessage(`Files sorted by ${sortBy}`);
  }
});