// Animations JavaScript
document.addEventListener('DOMContentLoaded', function() {
  // Create floating animation for hero section
  const floatingElements = document.querySelectorAll('.cloud-icon, .document-icon');
  
  floatingElements.forEach(element => {
    // Add random delay to each element
    const randomDelay = Math.random() * 2;
    element.style.animationDelay = `${randomDelay}s`;
  });
  
  // Progress bar animation for file uploads
  const simulateUploadProgress = function(progressFill, progressPercent, onComplete) {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 10;
      if (progress > 100) progress = 100;
      
      progressFill.style.width = `${progress}%`;
      progressFill.style.setProperty('--progress-percent', `${progress}%`);
      
      if (progressPercent) {
        progressPercent.textContent = Math.round(progress);
      }
      
      if (progress >= 100) {
        clearInterval(interval);
        if (typeof onComplete === 'function') {
          setTimeout(onComplete, 500);
        }
      }
    }, 200);
    
    return {
      cancel: () => clearInterval(interval)
    };
  };
  
  // Export for other scripts
  window.simulateUploadProgress = simulateUploadProgress;
  
  // Donut chart animation
  const donutSegments = document.querySelectorAll('.donut-segment');
  
  donutSegments.forEach(segment => {
    const percentage = segment.style.getPropertyValue('--percentage');
    segment.style.transform = `rotate(${percentage * 3.6}deg)`;
  });
  
  // Contact form animation
  const contactForm = document.getElementById('contactForm');
  
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Add animation to submit button
      const submitBtn = contactForm.querySelector('button[type="submit"]');
      submitBtn.innerHTML = 'Sending...';
      submitBtn.disabled = true;
      
      // Simulate form submission
      setTimeout(() => {
        submitBtn.innerHTML = 'Message Sent!';
        submitBtn.classList.add('btn-success');
        
        // Reset form
        contactForm.reset();
        
        // Reset button after delay
        setTimeout(() => {
          submitBtn.innerHTML = 'Send Message';
          submitBtn.disabled = false;
          submitBtn.classList.remove('btn-success');
        }, 3000);
      }, 1500);
    });
  }
  
  // Parallax scroll effect
  const parallaxScroll = function() {
    const heroSection = document.querySelector('.hero');
    if (heroSection) {
      const scrollPosition = window.scrollY;
      heroSection.style.backgroundPosition = `center ${scrollPosition * 0.5}px`;
    }
  };
  
  window.addEventListener('scroll', parallaxScroll);
  
  // Animate numbers when in view
  const animateNumbers = function() {
    const statNumbers = document.querySelectorAll('.stat-number.visible');
    
    statNumbers.forEach(statNumber => {
      if (!statNumber.classList.contains('animated')) {
        statNumber.classList.add('animated');
        
        const finalValue = statNumber.textContent;
        let startValue = 0;
        
        // Handle different formats
        if (finalValue.includes('K')) {
          const value = parseFloat(finalValue) * 1000;
          const duration = Math.floor(1500 / value);
          let counter = 0;
          
          const timer = setInterval(() => {
            counter += 10;
            statNumber.textContent = `${Math.floor(counter / 100) / 10}K+`;
            
            if (counter >= value) {
              clearInterval(timer);
              statNumber.textContent = finalValue;
            }
          }, duration);
        } else if (finalValue.includes('PB')) {
          const value = parseFloat(finalValue);
          const duration = 1500 / 100;
          let counter = 0;
          
          const timer = setInterval(() => {
            counter++;
            statNumber.textContent = `${(counter / 20).toFixed(1)}PB+`;
            
            if (counter >= 100) {
              clearInterval(timer);
              statNumber.textContent = finalValue;
            }
          }, duration);
        } else if (finalValue.includes('%')) {
          const value = parseFloat(finalValue);
          const duration = 1500 / value;
          let counter = 0;
          
          const timer = setInterval(() => {
            counter++;
            statNumber.textContent = `${counter}%`;
            
            if (counter >= value) {
              clearInterval(timer);
              statNumber.textContent = finalValue;
            }
          }, duration);
        } else {
          statNumber.textContent = finalValue;
        }
      }
    });
  };
  
  // Check for stats in view
  window.addEventListener('scroll', animateNumbers);
  animateNumbers(); // Run once on load
});