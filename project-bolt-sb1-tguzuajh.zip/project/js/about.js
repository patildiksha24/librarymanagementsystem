// About Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
  // Timeline animation
  const timeline = document.querySelector('.timeline');
  
  if (timeline) {
    const timelineItems = timeline.querySelectorAll('.timeline-item');
    
    // Animate timeline items when they come into view
    const animateTimeline = function() {
      timelineItems.forEach(item => {
        const itemTop = item.getBoundingClientRect().top;
        const triggerPoint = window.innerHeight * 0.8;
        
        if (itemTop < triggerPoint) {
          item.classList.add('visible');
        }
      });
    };
    
    // Run on page load
    animateTimeline();
    
    // Run on scroll
    window.addEventListener('scroll', animateTimeline);
  }
  
  // Stats counter animation
  const statNumbers = document.querySelectorAll('.stat-number');
  
  const animateStats = function() {
    statNumbers.forEach(statNumber => {
      const statTop = statNumber.getBoundingClientRect().top;
      const triggerPoint = window.innerHeight * 0.8;
      
      if (statTop < triggerPoint) {
        statNumber.classList.add('visible');
      }
    });
  };
  
  // Run on page load
  animateStats();
  
  // Run on scroll
  window.addEventListener('scroll', animateStats);
  
  // Team member hover effect
  const teamMembers = document.querySelectorAll('.team-member');
  
  teamMembers.forEach(member => {
    member.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-10px)';
      this.style.boxShadow = '0 15px 30px rgba(0, 0, 0, 0.1)';
    });
    
    member.addEventListener('mouseleave', function() {
      this.style.transform = '';
      this.style.boxShadow = '';
    });
  });
  
  // Animate cloud elements in the mission section
  const cloudAnimation = document.querySelector('.cloud-animation');
  
  if (cloudAnimation) {
    // Create multiple data streams with different positions and delays
    for (let i = 0; i < 5; i++) {
      const dataStream = document.createElement('div');
      dataStream.className = 'data-stream';
      
      // Randomize position and animation
      const top = 30 + Math.random() * 40; // Between 30% and 70%
      const angle = -30 + Math.random() * 60; // Between -30deg and 30deg
      const delay = Math.random() * 2; // Between 0s and 2s
      
      dataStream.style.top = `${top}%`;
      dataStream.style.transform = `rotate(${angle}deg)`;
      dataStream.style.animationDelay = `${delay}s`;
      
      cloudAnimation.appendChild(dataStream);
    }
  }
  
  // Contact form validation
  const contactForm = document.getElementById('contactForm');
  
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Get form fields
      const nameInput = document.getElementById('name');
      const emailInput = document.getElementById('email');
      const messageInput = document.getElementById('message');
      
      // Simple validation
      let isValid = true;
      
      if (nameInput.value.trim() === '') {
        showInputError(nameInput, 'Name is required');
        isValid = false;
      } else {
        clearInputError(nameInput);
      }
      
      if (emailInput.value.trim() === '') {
        showInputError(emailInput, 'Email is required');
        isValid = false;
      } else if (!isValidEmail(emailInput.value)) {
        showInputError(emailInput, 'Please enter a valid email');
        isValid = false;
      } else {
        clearInputError(emailInput);
      }
      
      if (messageInput.value.trim() === '') {
        showInputError(messageInput, 'Message is required');
        isValid = false;
      } else {
        clearInputError(messageInput);
      }
      
      if (isValid) {
        // Simulate form submission
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;
        
        setTimeout(() => {
          // Show success message
          const formContainer = contactForm.parentElement;
          formContainer.innerHTML = `
            <div class="form-success">
              <div class="success-icon">✓</div>
              <h3>Message Sent!</h3>
              <p>Thank you for reaching out. We'll get back to you shortly.</p>
            </div>
          `;
        }, 1500);
      }
    });
    
    function showInputError(input, message) {
      const formGroup = input.parentElement;
      
      // Clear any existing error
      clearInputError(input);
      
      // Add error class to input
      input.classList.add('input-error');
      
      // Create error message
      const errorElement = document.createElement('div');
      errorElement.className = 'error-message';
      errorElement.textContent = message;
      
      formGroup.appendChild(errorElement);
    }
    
    function clearInputError(input) {
      const formGroup = input.parentElement;
      const errorElement = formGroup.querySelector('.error-message');
      
      input.classList.remove('input-error');
      
      if (errorElement) {
        formGroup.removeChild(errorElement);
      }
    }
    
    function isValidEmail(email) {
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return regex.test(email);
    }
  }
});